import React, {Component} from 'react';

export default class Library extends Component {
  render() {
    return(
      <div>
        <h1> My Books Library </h1>
        <p> Explore my library </p>
      </div>

    )

  }
}
