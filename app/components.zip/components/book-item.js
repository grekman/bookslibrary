import React, {Component} from 'react';
export default class BookItem extends Component {
  render(){
    return(
      <h1>Book description</h1>
    );
  }
};
