import React, {Component} from 'react';
import {Link} from 'react-router';

export default class BooksList extends Component {
  render() {
    return (
      <ul>
        <li><Link to="book/1" >Book 1</Link></li>
        <li><Link to="book/2" >Book 2</Link></li>
        <li><Link to="book/3" >Book 3</Link></li>
        <li><Link to="book/4" >Book 4</Link></li>
        <li><Link to="book/5" >Book 5</Link></li>
        <li><Link to="book/6" >Book 6</Link></li>
        <li><Link to="book/7" >Book 7</Link></li>
        <li><Link to="book/8" >Book 8</Link></li>
        <li><Link to="book/9" >Book 9</Link></li>
        <li><Link to="book/10">Book 10</Link></li>
      </ul>

    )

  }
}
