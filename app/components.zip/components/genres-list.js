import React, {Component} from 'react';
import {Link} from 'react-router';

export default class GenresList extends Component {
  render() {
    return (
      <ul>
        <li><Link to="genres/1" >Genre 1</Link></li>
        <li><Link to="genres/2" >Genre 2</Link></li>
        <li><Link to="genres/3" >Genre 3</Link></li>
        <li><Link to="genres/4" >Genre 4</Link></li>
        <li><Link to="genres/5" >Genre 5</Link></li>
        <li><Link to="genres/6" >Genre 6</Link></li>
        <li><Link to="genres/7" >Genre 7</Link></li>
        <li><Link to="genres/8" >Genre 8</Link></li>
        <li><Link to="genres/9" >Genre 9</Link></li>
        <li><Link to="genres/10">Genre 10</Link></li>
      </ul>

    )

  }
}
